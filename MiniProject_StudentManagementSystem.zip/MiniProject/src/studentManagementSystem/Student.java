package studentManagementSystem;

import java.util.Scanner;

public class Student {

	String firstName1;
	String lastName;
	int classCode;
	String studentID;
    String courses;
	int tutionBalance;
	int costOfCourse =1500;
	int id=1000;
	
	public Student()
	{
		Scanner in=new Scanner(System.in);
		
		System.out.println("Enter student first name:");
		this.firstName1=in.nextLine();
		
		System.out.println("Enter student last name:");
		this.lastName=in.nextLine();
		
		System.out.println("\n Enter in which class you want take admission: - \n 1.-11th standard.\n 2.-12 th standard \n 3.-diploma \n 4.-B.Tech \n 5.-M.Tech:");
		this.classCode=in.nextInt();
		
		
		setStudentID();
		

}
	private void setStudentID()
	{
		id++;

		this.studentID = classCode +""+id;
	}
	
	public void enroll(){
		
		do{
		System.out.print("Enter Enrolled Course for tution: (Q to Quit):");
		Scanner in=new Scanner(System.in);
		String course = in.nextLine();
		if(!course.equals("Q"))
		{
			courses = courses+"\n-"+course;
			tutionBalance=tutionBalance +costOfCourse;
			
		}
		else {
			System.out.println("BREAK");
			
			break;
			}
		}
		while(1 != 0);
		
		
	}
	public void viewBalance()

	{
		System.out.println("Your Tuition Fee Is : " +tutionBalance);
	}
	
	public void payTution(int payment)
	{
		viewBalance();
		System.out.print("Pay tuition fee: ");
		Scanner in=new Scanner(System.in);
		int payment1 =in.nextInt();
		tutionBalance=tutionBalance-payment1;
		System.out.println(("THANK YOU FOR YOUR:  "+payment1));
		viewBalance();
	}
	
	public String toString(){
		return  "\n************************"+""+ 
	            "\nShow Status: "+"\n************************"+
	            "\nName:" +firstName1 +" "+lastName+
				"\nClassCode : "+classCode +
				"\nStudentID   :  "+studentID+
				"\ncourses Enrolled :"+courses+ "\nVeiw Remaining Balance: "+tutionBalance+
				"\n************************";
				
	}
}
